package com.tutorial.mario.gfx;

import java.awt.image.BufferedImage;

public class SpriteSheet {
	
	private BufferedImage sheet;
	
	public SpriteSheet(String path) { // 2:12
		
	}

}

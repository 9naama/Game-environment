package com.tutorial.mario;

public enum Id {
	player, wall;
	
}

package com.tutorial.mario.gfx;

public class Sprite {

}
